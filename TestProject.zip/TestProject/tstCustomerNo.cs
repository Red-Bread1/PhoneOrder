﻿using ClassLibrary;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using System;

namespace TestProject
{
    [TestClass]
    public class tstCustomerNo
    {
        [TestMethod]
        public void InstanceOK()
        {
            //create an instance of the class we want to create
            clsOrder ACustomerNo = new clsOrder();
            //test to see that it exists
            Assert.IsNotNull(ACustomerNo);
        }
        [TestMethod]
        public void CustomerNoPropertyOK()
        {
            //create an instance of the class we want to create
            clsOrder AnOrder = new clsOrder();
            //create some test data to assign to the property
            Int32 TestData = 1;
            //create some test data
            AnOrder.CustomerNo = TestData;
            //test to see that the two values are the same
            Assert.AreEqual(AnOrder.CustomerNo, TestData);
        }
        [TestMethod]
        public void ValidMethodOK()
        {
            //create an instance of the class we want to create
            clsOrder ACustomerNo = new clsOrder();
            //create a string variable to store the result of the validation
            String Error = "";
            //create some test data to test the method
            string SomeCustomerNo = "";
            //invoke the method
            Error = ACustomerNo.Valid(SomeCustomerNo);
            //test to see that the result is OK i.e there was no error message returned
            Assert.AreEqual(Error, "");
        }
        public void CustomerNoMinLessOne()
        {
            //create an instance of the class we want to create
            clsOrderCollection ACustomerNo = new clsOrderCollection();
            //create a string variable to store the result of the validation
            String Error = "";
            //create some test data to test the method
            string SomeCustomerNo = "";
            //invoke the method
            Error = ACustomerNo.Valid(SomeCustomerNo);
            //test to see that the result is not ok i.e there should be an error message
            Assert.AreNotEqual(Error, "");
        }
        [TestMethod]
        public void CustomerNoMinBoundary()
        {
            //create an instance of the class we want to create
            clsOrderCollection ACustomerNo = new clsOrderCollection();
            //create a string variable to store the result of the validation
            String Error = "";
            //create some test data to test the method
            string SomeCustomerNo = "a";
            //invoke the method
            Error = ACustomerNo.Valid(SomeCustomerNo);
            //test to see that the result is ok i.e there should be an error message
            Assert.AreEqual(Error, "");
        }
        [TestMethod]
        public void CustomerNoMinPlusOne()
        {
            //create an instance of the class we want to create
            clsOrderCollection ACustomerNo = new clsOrderCollection();
            //create a string variable to store the result of the validation
            String Error = "";
            //create some test data to test the method
            string SomeCustomerNo = "aa";
            //invoke the method
            Error = ACustomerNo.Valid(SomeCustomerNo);
            //test to see that the result is ok i.e there should be an error message
            Assert.AreEqual(Error, "");
        }
        [TestMethod]
        public void CustomerNoMaxLessOne()
        {
            //create an instance of the class we want to create
            clsOrderCollection ACustomerNo = new clsOrderCollection();
            //create a string variable to store the result of the validation
            String Error = "";
            //create some test data to test the method
            string SomeCustomerNo = "0123456789012345678";
            //invoke the method
            Error = ACustomerNo.Valid(SomeCustomerNo);
            //test to see that the result is ok i.e there should be an error message
            Assert.AreEqual(Error, "");
        }
        [TestMethod]
        public void CustomerNoMaxBoundary()
        {
            //create an instance of the class we want to create
            clsOrderCollection ACustomerNo = new clsOrderCollection();
            //create a string variable to store the result of the validation
            String Error = "";
            //create some test data to test the method
            string SomeCustomerNo = "01234567890123456789";
            //invoke the method
            Error = ACustomerNo.Valid(SomeCustomerNo);
            //test to see that the result is ok i.e there should be an error message
            Assert.AreEqual(Error, "");
        }
        [TestMethod]
        public void CustomerNoMaxPlusOne()
        {
            //create an instance of the class we want to create
            clsOrderCollection ACustomerNo = new clsOrderCollection();
            //create a string variable to store the result of the validation
            String Error = "";
            //create some test data to test the method
            string SomeCustomerNo = "012345678901234567890";
            //invoke the method
            Error = ACustomerNo.Valid(SomeCustomerNo);
            //test to see that the result is not ok i.e there should be an error message
            Assert.AreNotEqual(Error, "");
        }
        [TestMethod]
        public void CustomerNoMid()
        {
            //create an instance of the class we want to create
            clsOrderCollection ACustomerNo = new clsOrderCollection();
            //create a string variable to store the result of the validation
            String Error = "";
            //create some test data to test the method
            string SomeCustomerNo = "0123456789";
            //invoke the method
            Error = ACustomerNo.Valid(SomeCustomerNo);
            //test to see that the result is ok i.e there should be an error message
            Assert.AreEqual(Error, "");
        }
        [TestMethod]
        public void CustomerNoExtremeMax()
        {
            //create an instance of the class we want to create
            clsOrderCollection ACustomerNo = new clsOrderCollection();
            //create a string variable to store the result of the validation
            String Error = "";
            //create some test data to test the method
            string SomeCustomerNo = "";
            //pad the string with characters
            SomeCustomerNo = SomeCustomerNo.PadRight(500, 'a');
            //invoke the method
            Error = ACustomerNo.Valid(SomeCustomerNo);
            //test to see that the result is not ok i.e there should be an error message
            Assert.AreNotEqual(Error, "");
        }
    }
}
