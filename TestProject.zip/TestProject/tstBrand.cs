﻿using System;
using ClassLibrary;
using Microsoft.VisualStudio.TestTools.UnitTesting;

namespace TestProject
{
    [TestClass]
    public class tstBrand
    {
        [TestMethod]
        public void InstanceOK()
        {
            //create an instance of the class we want to create
            clsBrand ABrand = new clsBrand();
            //test to see that it exists
            Assert.IsNotNull(ABrand);
        }
        [TestMethod]
        public void BrandPropertyOK()
        {
            //create an instance of the class we want to create
            clsBrand ABrand = new clsBrand();
            //create some test data to assign to the property
            string SomeBrand = "Apple";
            //assign the data to the property
            ABrand.Brand = SomeBrand;
            //test to see that the two values are the same
            Assert.AreEqual(ABrand.Brand, SomeBrand);
        }
        [TestMethod]
        public void ValidMethodOK()
        {
            //create an instance of the class we want to create
            clsBrand ABrand = new clsBrand();
            //create a string variable to store the result of the validation
            String Error = "";
            //create some test data to test the method
            string SomeBrand = "Apple";
            //invoke the method
            Error = ABrand.Valid(SomeBrand);
            //test to see that the result is OK i.e there was no error message returned
            Assert.AreEqual(Error, "");
        }
        public void BrandMinLessOne()
        {
            //create an instance of the class we want to create
            clsBrand ABrand = new clsBrand();
            //create a string variable to store the result of the validation
            String Error = "";
            //create some test data to test the method
            string SomeBrand = "";
            //invoke the method
            Error = ABrand.Valid(SomeBrand);
            //test to see that the result is not ok i.e there should be an error message
            Assert.AreNotEqual(Error, "");
        }
        [TestMethod]
        public void BrandMinBoundary()
        {
            //create an instance of the class we want to create
            clsBrand ABrand = new clsBrand();
            //create a string variable to store the result of the validation
            String Error = "";
            //create some test data to test the method
            string SomeBrand = "a";
            //invoke the method
            Error = ABrand.Valid(SomeBrand);
            //test to see that the result is ok i.e there should be an error message
            Assert.AreEqual(Error, "");
        }
        [TestMethod]
        public void BrandMinPlusOne()
        {
            //create an instance of the class we want to create
            clsBrand ABrand = new clsBrand();
            //create a string variable to store the result of the validation
            String Error = "";
            //create some test data to test the method
            string SomeBrand = "aa";
            //invoke the method
            Error = ABrand.Valid(SomeBrand);
            //test to see that the result is ok i.e there should be an error message
            Assert.AreEqual(Error, "");
        }
        [TestMethod]
        public void BrandMaxLessOne()
        {
            //create an instance of the class we want to create
            clsBrand ABrand = new clsBrand();
            //create a string variable to store the result of the validation
            String Error = "";
            //create some test data to test the method
            string SomeBrand = "0123456789012345678";
            //invoke the method
            Error = ABrand.Valid(SomeBrand);
            //test to see that the result is ok i.e there should be an error message
            Assert.AreEqual(Error, "");
        }
        [TestMethod]
        public void BrandMaxBoundary()
        {
            //create an instance of the class we want to create
            clsBrand ABrand = new clsBrand();
            //create a string variable to store the result of the validation
            String Error = "";
            //create some test data to test the method
            string SomeBrand = "01234567890123456789";
            //invoke the method
            Error = ABrand.Valid(SomeBrand);
            //test to see that the result is ok i.e there should be an error message
            Assert.AreEqual(Error, "");
        }
        [TestMethod]
        public void BrandMaxPlusOne()
        {
            //create an instance of the class we want to create
            clsBrand ABrand = new clsBrand();
            //create a string variable to store the result of the validation
            String Error = "";
            //create some test data to test the method
            string SomeBrand = "012345678901234567890";
            //invoke the method
            Error = ABrand.Valid(SomeBrand);
            //test to see that the result is not ok i.e there should be an error message
            Assert.AreNotEqual(Error, "");
        }
        [TestMethod]
        public void BrandMid()
        {
            //create an instance of the class we want to create
            clsBrand ABrand = new clsBrand();
            //create a string variable to store the result of the validation
            String Error = "";
            //create some test data to test the method
            string SomeBrand = "0123456789";
            //invoke the method
            Error = ABrand.Valid(SomeBrand);
            //test to see that the result is ok i.e there should be an error message
            Assert.AreEqual(Error, "");
        }
        [TestMethod]
        public void BrandExtremeMax()
        {
            //create an instance of the class we want to create
            clsBrand ABrand = new clsBrand();
            //create a string variable to store the result of the validation
            String Error = "";
            //create some test data to test the method
            string SomeBrand = "";
            //pad the string with characters
            SomeBrand = SomeBrand.PadRight(500, 'a');
            //invoke the method
            Error = ABrand.Valid(SomeBrand);
            //test to see that the result is not ok i.e there should be an error message
            Assert.AreNotEqual(Error, "");
        }
    }
}
