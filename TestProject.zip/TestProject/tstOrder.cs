﻿using ClassLibrary;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using System;

namespace TestProject
{
    [TestClass]
    public class tstOrder
    {
        [TestMethod]
        public void FindMethodOK()
        {
            //create an instance of the class we want to create
            clsOrder AnOrder = new clsOrder();
            //Boolean variable to store the results of the validation
            Boolean Found = false;
            //create some test data to use with the method
            Int32 OrderNo = 1;
            //invoke the method
            Found = AnOrder.Find(OrderNo);
            //test to see if the result is true
            Assert.IsTrue(Found);
        }
    }

    [TestMethod]
    public void TestOrderNoFound()
    {
        //create an instance of the class we want to create
        clsOrder AnOrder = new clsOrder();
        //boolean variable to store the result of the search
        Boolean Found = false;
        //boolean variable to record if data is OK (assume it is)
        Boolean OK = true;
        //create some test data to use with the method
        Int32 OrderNo = 21;
        //invoke the method
        Found = AnOrder.Find(OrderNo);
        //check the order no
        if (AnOrder.OrderNo != 21)
        {
            OK = false;
        }
        //test to see that the result is correct
        Assert.IsTrue(OK);
    }
    public void TestCustomerNoFound()
    {
        //create an instance of the class we want to create
        clsOrder AnOrder = new clsOrder();
        //boolean variable to store the result of the search
        Boolean Found = false;
        //boolean variable to record if data is OK (assume it is)
        Boolean OK = true;
        //create some test data to use with the method
        String OrderNo = "";
        //invoke the method
        Found = AnOrder.Find(OrderNo);
        //check the property
        if (AnOrder.CustomerNo != "Test CustomerNo")
        {
            OK = false;
        }
        //test to see that the result is correct
        Assert.IsTrue(OK);
    }

    [TestMethod]
    public void TestBrandFound()
    {
        //create an instance of the class we want to create
        clsBrand AnOrder = new clsBrand();
        //boolean variable to store the result of the search
        Boolean Found = false;
        //boolean variable to record if data is OK (assume it is)
        Boolean OK = true;
        //create some test data to use with the method
        Int32 OrderNo = 21;
        //invoke the method
        Found = AnOrder.Find(OrderNo);
        //check the property
        if (AnOrder.Brand != "Test Brand")
        {
            OK = false;
        }
        //test to see that the result is correct
        Assert.IsTrue(OK);
    }
    [TestMethod]
    public void TestModelFound()
    {
        //create an instance of the class we want to create
        clsModel AnOrder = new clsModel();
        //boolean variable to store the result of the search
        Boolean Found = false;
        //boolean variable to record if data is OK (assume it is)
        Boolean OK = true;
        //create some test data to use with the method
        Int32 OrderNo = 21;
        //invoke the method
        Found = AnOrder.Find(OrderNo);
        //check the property
        if (AnOrder.Model != "Test Model")
        {
            OK = false;
        }
        //test to see that the result is correct
        Assert.IsTrue(OK);
    }
    [TestMethod]
    public void TestManufacturerFound()
    {
        //create an instance of the class we want to create
        clsManufacturer AnOrder = new clsManufacturer();
        //boolean variable to store the result of the search
        Boolean Found = false;
        //boolean variable to record if data is OK (assume it is)
        Boolean OK = true;
        //create some test data to use with the method
        Int32 OrderNo = 21;
        //invoke the method
        Found = AnOrder.Find(OrderNo);
        //check the property
        if (AnOrder.Manufacturer != "Test Manufacturer")
        {
            OK = false;
        }
        //test to see that the result is correct
        Assert.IsTrue(OK);
    }
    [TestMethod]
    public void TestPriceFound()
    {
        //create an instance of the class we want to create
        clsPrice AnOrder = new clsPrice();
        //boolean variable to store the result of the search
        Boolean Found = false;
        //boolean variable to record if data is OK (assume it is)
        Boolean OK = true;
        //create some test data to use with the method
        Int32 OrderNo = 21;
        //invoke the method
        Found = AnOrder.Find(OrderNo);
        //check the property
        if (AnOrder.Price != "Test Price")
        {
            OK = false;
        }
        //test to see that the result is correct
        Assert.IsTrue(OK);
    }
    [TestMethod]
    public void TestDateAddedFound()
    {
        //create an instance of the class we want to create
        clsOrder AnOrder = new clsOrder();
        //boolean variable to store the result of the search
        Boolean Found = false;
        //boolean variable to record if the data is OK (assume it is)
        Boolean OK = true;
        //create some test data to use with the method
        Int32 OrderNo = 21;
        //invoke the method
        Found = AnOrder.Find(OrderNo);
        //check the property
        if (AnOrder.DateAdded != Convert.ToDateTime("16/09/2015"))
        {
            OK = false;
        }
        //test to see that the results are correct
        Assert.IsTrue(OK);
    }
    [TestMethod]
    public void TestActiveFound()
    {
        //create an instance of the class we want to create
        clsOrder AnOrder = new clsOrder();
        //boolean variable to store the result of the search
        Boolean Found = false;
        //boolean variable to record if data is OK (assume it is)
        Boolean OK = true;
        //create some test data to use with the method
        Int32 OrderNo = 21;
        //invoke the method
        Found = AnOrder.Find(OrderNo);
        //check the property
        if (AnOrder.Active != true)
        {
            OK = false;
        }
        //test to see that the result is correct
        Assert.IsTrue(OK);
    }
    [TestMethod]
    public void AddMethodOK()
    {
        //create an instance of the class we want to create
        clsOrderCollection AllOrders = new clsOrderCollection();
        //create the item of test data
        clsOrder TestItem = new clsOrder();
        //var to store the primary key
        Int32 PrimaryKey = 0;
        //set the properties
        TestItem.Active = true;
        TestItem.OrderNo = 1;
        TestItem.CustomerNo = 1;
        TestItem.DateAdded = DateTime.Now.Date;
        TestItem.Brand = "some brand";
        TestItem.Model = "some model";
        TestItem.Manufacturer = "some manufacturer";
        TestItem.Price = "£500";
        //set ThisOrder to the test data
        AllOrders.ThisOrder = TestItem;
        //add the record
        PrimaryKey = AllOrders.Add();
        //set the primary key of the test data
        TestItem.OrderNo = PrimaryKey;
        //find the record
        AllOrders.ThisOrder.Find(PrimaryKey);
        //test to see that the two values are the same
        Assert.AreEqual(AllOrders.ThisOrder, TestItem);
    }
    [TestMethod]
    public void DeleteMethodOK()
    {
        //create an instance of the class we want to create
        clsOrderCollection AllOrders = new clsOrderCollection();
        //create the item of test data
        clsOrder TestItem = new clsOrder();
        //var to store the primary key
        Int32 PrimaryKey = 0;
        //set the properties
        TestItem.Active = true;
        TestItem.OrderNo = 1;
        TestItem.CustomerNo = 1;
        TestItem.DateAdded = DateTime.Now.Date;
        TestItem.Brand = "some brand";
        TestItem.Model = "some model";
        TestItem.Manufacturer = "some manufacturer";
        TestItem.Price = "£500";
        //set ThisOrder to the test data
        AllOrders.ThisOrder = TestItem;
        //add the record
        PrimaryKey = AllOrders.Add();
        //set the primary key of the test data
        TestItem.OrderNo = PrimaryKey;
        //find the record
        AllOrders.ThisOrder.Find(PrimaryKey);
        //delete the record
        AllOrders.Delete();
        Boolean Found = AllOrders.ThisOrder.Find(PrimaryKey);
        //test to see that the record was not found
        Assert.IsFalse(Found);
    }
    [TestMethod]
    public void UpdateMethod()
    {
        //create an instance of the class we want to create
        clsOrderCollection AllOrders = new clsOrderCollection();
        //create the item of test data
        clsOrder TestItem = new clsOrder();
        //var to store the primary key
        Int32 PrimaryKey = 0;
        //set the properties
        TestItem.Active = true;
        TestItem.CustomerNo = 1;
        TestItem.DateAdded = DateTime.Now.Date;
        TestItem.Brand = "some brand";
        TestItem.Model = "some model";
        TestItem.Manufacturer = "some manufacturer";
        TestItem.Price = "£500";
        //set ThisOrder to the test data
        AllOrders.ThisOrder = TestItem;
        //add the record
        PrimaryKey = AllOrders.Add();
        //set the primary key of the test data
        TestItem.OrderNo = PrimaryKey;
        //modify the test data
        TestItem.Active = true;
        TestItem.CustomerNo = 3;
        TestItem.DateAdded = DateTime.Now.Date;
        TestItem.Brand = "some brand";
        TestItem.Model = "some model";
        TestItem.Manufacturer = "some manufacturer";
        TestItem.Price = "£500";
        //set the record based on the new test data
        AllOrders.ThisOrder = TestItem;
        //update the record
        AllOrders.Update();
        //find the record
        AllOrders.ThisOrders.Find(PrimaryKey);
        //test to see ThisOrder matches the test data
        Assert.AreEqual(AllOrders.ThisOrder, TestItem);
    }
}
