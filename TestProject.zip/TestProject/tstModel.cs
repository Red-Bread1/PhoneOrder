﻿using System;
using ClassLibrary;
using Microsoft.VisualStudio.TestTools.UnitTesting;

namespace TestProject
{
    [TestClass]
    public class tstModel
    {
        [TestMethod]
        public void InstanceOK()
        {
            //create an instance of the class we want to create
            clsModel AModel = new clsModel();
            //test to see that it exists
            Assert.IsNotNull(AModel);
        }
        [TestMethod]
        public void ModelPropertyOK()
        {
            //create an instance of the class we want to create
            clsModel AModel = new clsModel();
            //create some test data to assign to the property
            string SomeModel = "Apple";
            //assign the data to the property
            AModel.Model = SomeModel;
            //test to see that the two values are the same
            Assert.AreEqual(AModel.Model, SomeModel);
        }
        [TestMethod]
        public void ValidMethodOK()
        {
            //create an instance of the class we want to create
            clsModel AModel = new clsModel();
            //create a string variable to store the result of the validation
            String Error = "";
            //create some test data to test the method
            string SomeModel = "Model 11";
            //invoke the method
            Error = AModel.Valid(SomeModel);
            //test to see that the result is OK i.e there was no error message returned
            Assert.AreEqual(Error, "");
        }
        public void ModelMinLessOne()
        {
            //create an instance of the class we want to create
            clsModel AModel = new clsModel();
            //create a string variable to store the result of the validation
            String Error = "";
            //create some test data to test the method
            string SomeModel = "";
            //invoke the method
            Error = AModel.Valid(SomeModel);
            //test to see that the result is not ok i.e there should be an error message
            Assert.AreNotEqual(Error, "");
        }
        [TestMethod]
        public void ModelMinBoundary()
        {
            //create an instance of the class we want to create
            clsModel AModel = new clsModel();
            //create a string variable to store the result of the validation
            String Error = "";
            //create some test data to test the method
            string SomeModel = "a";
            //invoke the method
            Error = AModel.Valid(SomeModel);
            //test to see that the result is ok i.e there should be an error message
            Assert.AreEqual(Error, "");
        }
        [TestMethod]
        public void ModelMinPlusOne()
        {
            //create an instance of the class we want to create
            clsModel AModel = new clsModel();
            //create a string variable to store the result of the validation
            String Error = "";
            //create some test data to test the method
            string SomeModel = "aa";
            //invoke the method
            Error = AModel.Valid(SomeModel);
            //test to see that the result is ok i.e there should be an error message
            Assert.AreEqual(Error, "");
        }
        [TestMethod]
        public void ModelMaxLessOne()
        {
            //create an instance of the class we want to create
            clsModel AModel = new clsModel();
            //create a string variable to store the result of the validation
            String Error = "";
            //create some test data to test the method
            string SomeModel = "0123456789012345678";
            //invoke the method
            Error = AModel.Valid(SomeModel);
            //test to see that the result is ok i.e there should be an error message
            Assert.AreEqual(Error, "");
        }
        [TestMethod]
        public void ModelMaxBoundary()
        {
            //create an instance of the class we want to create
            clsModel AModel = new clsModel();
            //create a string variable to store the result of the validation
            String Error = "";
            //create some test data to test the method
            string SomeModel = "01234567890123456789";
            //invoke the method
            Error = AModel.Valid(SomeModel);
            //test to see that the result is ok i.e there should be an error message
            Assert.AreEqual(Error, "");
        }
        [TestMethod]
        public void ModelMaxPlusOne()
        {
            //create an instance of the class we want to create
            clsModel AModel = new clsModel();
            //create a string variable to store the result of the validation
            String Error = "";
            //create some test data to test the method
            string SomeModel = "012345678901234567890";
            //invoke the method
            Error = AModel.Valid(SomeModel);
            //test to see that the result is not ok i.e there should be an error message
            Assert.AreNotEqual(Error, "");
        }
        [TestMethod]
        public void ModelMid()
        {
            //create an instance of the class we want to create
            clsModel AModel = new clsModel();
            //create a string variable to store the result of the validation
            String Error = "";
            //create some test data to test the method
            string SomeModel = "0123456789";
            //invoke the method
            Error = AModel.Valid(SomeModel);
            //test to see that the result is ok i.e there should be an error message
            Assert.AreEqual(Error, "");
        }
        [TestMethod]
        public void ModelExtremeMax()
        {
            //create an instance of the class we want to create
            clsModel AModel = new clsModel();
            //create a string variable to store the result of the validation
            String Error = "";
            //create some test data to test the method
            string SomeModel = "";
            //pad the string with characters
            SomeModel = SomeModel.PadRight(500, 'a');
            //invoke the method
            Error = AModel.Valid(SomeModel);
            //test to see that the result is not ok i.e there should be an error message
            Assert.AreNotEqual(Error, "");
        }
    }
}
