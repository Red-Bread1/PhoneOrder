﻿using Microsoft.VisualStudio.TestTools.UnitTesting;
using System;
using System.Collections.Generic;

namespace TestProject
{
    [TestClass]
    public class tstPriceCollection
    {
        [TestMethod]
        public void InstanceOK()
        {
            //create an instance of the class we want to create
            clsOrderCollection AllPrices = new clsOrderCollection();
            //test to see that it exists
            Assert.IsNotNull(AllPrices);
        }
        [TestMethod]
        public void CountPropertyOK()
        {
            //create an instance of the class we want to create
            clsOrderCollection AllPrices = new clsOrderCollection();
            //create some test data to assign to the property
            Int32 SomeCount = 2;
            //assign the data to the property
            AllPrices.Count = SomeCount;
            //test to see that the two values are the same
            Assert.AreEqual(AllPrices.Count, SomeCount);
        }
        [TestMethod]
        public void AllPricesOK()
        {
            //create an instance of the class we want to create
            clsOrderCollection Prices = new clsOrderCollection();
            //create some test data to assign to the property
            //in this case the data needs to be a list of objects
            List<clsPrice> TestList = new List<clsPrice>();
            //add an item to the list
            //create the item of test data
            clsPrice TestItem = new clsPrice();
            //set its properties
            TestItem.PriceNo = 1;
            TestItem.Price = "1000" +
                "";
            //add the item to the test list
            TestList.Add(TestItem);
            //assign the data to the property
            Prices.AllPrices = TestList;
            //test to see that the two values are the same
            Assert.AreEqual(Prices.AllPrices, TestList);
        }
        public class clsOrderCollection
        {
            //private data memeber for the allCounties list
            private List<clsPrice> mAllPrices = new List<clsPrice>();
            //publc property for Count
            public int Count
            {
                get
                {
                    //return the count property of the private list
                    return mAllPrices.Count;
                }
                set
                {
                    //we will look at this in a moment
                }
            }
            //public property for allPrices
            public List<clsPrice> AllPrices
            {
                //getter send data to requesting code
                get
                {
                    //return the private data member
                    return mAllPrices;
                }
                //setter accepts data from other objects
                set
                {
                    //assign the incoming value to the private data member
                    mAllPrices = value;
                }
            }

            //public constructor for the class
            public clsOrderCollection()
            {
                //create an instance of the Price class to store a Price
                clsPrice APrice = new clsPrice();
                //set the Price to Apple
                APrice.Price = "Price";
                //add the Price to the private lists of Prices
                mAllPrices.Add(APrice);
                //re initialise the APrice object to accept a new item
                APrice = new clsPrice();
                //set the county to Samsung
                APrice.Price = "500";
                //add the second Price to the private list of Prices
                mAllPrices.Add(APrice);
                //the private list now contains two Prices
            }
        }
    }
}
