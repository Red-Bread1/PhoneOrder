﻿using ClassLibrary;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using System;

namespace TestProject
{
    [TestMethod]
    public void InstanceOK()
    {
        //create an instance of the class we want to create
        clsOrder AOrder = new clsOrder();
        //test to see that it exists
        Assert.IsNotNull(AOrder);
    }
    [TestMethod]
    public void PricePropertyOK()
    {
        //create an instance of the class we want to create
        clsOrder AOrder = new clsOrder();
        //create some test data to assign to the property
        string SomePrice = "£500";
        //assign the data to the property
        AOrder.Price = SomePrice;
        //test to see that the two values are the same
        Assert.AreEqual(AOrder.Price, SomePrice);
    }
    [TestMethod]
    public void ValidMethodOK()
    {
        //create an instance of the class we want to create
        clsOrder AOrder = new clsOrder();
        //create a string variable to store the result of the validation
        String Error = "";
        //create some test data to test the method
        string SomePrice = "£1000";
        //invoke the method
        Error = AOrder.Valid(SomePrice);
        //test to see that the result is OK i.e there was no error message returned
        Assert.AreEqual(Error, "");
    }
    public void PriceMinLessOne()
    {
        //create an instance of the class we want to create
        clsOrder APrice = new clsOrder();
        //create a string variable to store the result of the validation
        String Error = "";
        //create some test data to test the method
        string SomePrice = "";
        //invoke the method
        Error = APrice.Valid(SomePrice);
        //test to see that the result is not ok i.e there should be an error message
        Assert.AreNotEqual(Error, "");
    }
    [TestMethod]
    public void PriceMinBoundary()
    {
        //create an instance of the class we want to create
        clsOrder APrice = new clsOrder();
        //create a string variable to store the result of the validation
        String Error = "";
        //create some test data to test the method
        string SomePrice = "a";
        //invoke the method
        Error = APrice.Valid(SomePrice);
        //test to see that the result is ok i.e there should be an error message
        Assert.AreEqual(Error, "");
    }
    [TestMethod]
    public void PriceMinPlusOne()
    {
        //create an instance of the class we want to create
        clsOrder APrice = new clsOrder();
        //create a string variable to store the result of the validation
        String Error = "";
        //create some test data to test the method
        string SomePrice = "aa";
        //invoke the method
        Error = APrice.Valid(SomePrice);
        //test to see that the result is ok i.e there should be an error message
        Assert.AreEqual(Error, "");
    }
    [TestMethod]
    public void PriceMaxLessOne()
    {
        //create an instance of the class we want to create
        clsOrder APrice = new clsOrder();
        //create a string variable to store the result of the validation
        String Error = "";
        //create some test data to test the method
        string SomePrice = "0123456789012345678";
        //invoke the method
        Error = APrice.Valid(SomePrice);
        //test to see that the result is ok i.e there should be an error message
        Assert.AreEqual(Error, "");
    }
    [TestMethod]
    public void PriceMaxBoundary()
    {
        //create an instance of the class we want to create
        clsOrder APrice = new clsOrder();
        //create a string variable to store the result of the validation
        String Error = "";
        //create some test data to test the method
        string SomePrice = "01234567890123456789";
        //invoke the method
        Error = APrice.Valid(SomePrice);
        //test to see that the result is ok i.e there should be an error message
        Assert.AreEqual(Error, "");
    }
    [TestMethod]
    public void PriceMaxPlusOne()
    {
        //create an instance of the class we want to create
        clsOrder APrice = new clsOrder();
        //create a string variable to store the result of the validation
        String Error = "";
        //create some test data to test the method
        string SomePrice = "012345678901234567890";
        //invoke the method
        Error = APrice.Valid(SomePrice);
        //test to see that the result is not ok i.e there should be an error message
        Assert.AreNotEqual(Error, "");
    }
    [TestMethod]
    public void PriceMid()
    {
        //create an instance of the class we want to create
        clsOrder APrice = new clsOrder();
        //create a string variable to store the result of the validation
        String Error = "";
        //create some test data to test the method
        string SomePrice = "0123456789";
        //invoke the method
        Error = APrice.Valid(SomePrice);
        //test to see that the result is ok i.e there should be an error message
        Assert.AreEqual(Error, "");
    }
    [TestMethod]
    public void PriceExtremeMax()
    {
        //create an instance of the class we want to create
        clsOrder APrice = new clsOrder();
        //create a string variable to store the result of the validation
        String Error = "";
        //create some test data to test the method
        string SomePrice = "";
        //pad the string with characters
        SomePrice = SomePrice.PadRight(500, 'a');
        //invoke the method
        Error = APrice.Valid(SomePrice);
        //test to see that the result is not ok i.e there should be an error message
        Assert.AreNotEqual(Error, "");
    }
}
