﻿using ClassLibrary;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using System;
using System.Collections.Generic;

namespace TestProject
{
    [TestClass]
    public class tstCustomerNoCollection
    {
        [TestMethod]
        public void InstanceOK()
        {
            //create an instance of the class we want to create
            clsOrderCollection AllCustomerNos = new clsOrderCollection();
            //test to see that it exists
            Assert.IsNotNull(AllCustomerNos);
        }
        [TestMethod]
        public void CountPropertyOK()
        {
            //create an instance of the class we want to create
            clsOrderCollection AllCustomerNos = new clsOrderCollection();
            //create some test data to assign to the property
            Int32 SomeCount = 2;
            //assign the data to the property
            AllCustomerNos.Count = SomeCount;
            //test to see that the two values are the same
            Assert.AreEqual(AllCustomerNos.Count, SomeCount);
        }
        [TestMethod]
        public void AllCustomerNosOK()
        {
            //create an instance of the class we want to create
            clsOrderCollection CustomerNos = new clsOrderCollection();
            //create some test data to assign to the property
            //in this case the data needs to be a list of objects
            List<clsCustomerNo> TestList = new List<clsCustomerNo>();
            //add an item to the list
            //create the item of test data
            clsCustomerNo TestItem = new ClassLibrary.clsCustomerNo();
            //set its properties
            TestItem.CustomerNoNo = 1;
            TestItem.CustomerNo = "11";
            //add the item to the test list
            TestList.Add(TestItem);
            //assign the data to the property
            CustomerNos.AllCustomerNos = TestList;
            //test to see that the two values are the same
            Assert.AreEqual(CustomerNos.AllCustomerNos, TestList);
        }
    }
}
