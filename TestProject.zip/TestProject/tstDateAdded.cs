﻿using ClassLibrary;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using System;

namespace TestProject
{
    [TestClass]
    public class tstDateAdded
    {
        [TestMethod]
        public void InstanceOK()
        {
            //create an instance of the class we want to create
            clsOrder ADateAdded = new clsOrder();
            //test to see that it exists
            Assert.IsNotNull(ADateAdded);
        }
        [TestMethod]
        public void DateAddedPropertyOK()
        {
            //create an instance of the class we want to create
            clsOrder ADateAdded = new clsOrder();
            //create some test data to assign to the property
            DateTime SomeDateAdded = DateTime.Now.Date;
            //assign the data to the property
            ADateAdded.DateAdded = SomeDateAdded;
            //test to see that the two values are the same
            Assert.AreEqual(ADateAdded.DateAdded, SomeDateAdded);
        }
        [TestMethod]
        public void ValidMethodOK()
        {
            //create an instance of the class we want to create
            clsOrder ADateAdded = new clsOrder();
            //create a string variable to store the result of the validation
            String Error = "";
            //create some test data to test the method
            DateTime SomeDateAdded = DateTime.Now.Date;
            //invoke the method
            Error = ADateAdded.Valid(SomeDateAdded);
            //test to see that the result is OK i.e there was no error message returned
            Assert.AreEqual(Error, "");
        }
    }
}
